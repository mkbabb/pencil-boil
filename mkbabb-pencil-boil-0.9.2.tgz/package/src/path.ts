import { mulberry32 } from './random';

export interface WobbleOptions {
  roughness?: number;
  segments?: number;
  seed?: number;
  jagged?: boolean;
}

function toFinite(value: number | undefined, fallback: number): number {
  if (typeof value !== 'number' || Number.isNaN(value)) return fallback;
  return Number.isFinite(value) ? value : fallback;
}

function toPositiveInt(
  value: number | undefined,
  fallback: number,
  minimum: number = 1,
): number {
  const normalized = Math.floor(toFinite(value, fallback));
  return Math.max(minimum, normalized);
}

/**
 * Convert a set of points to a cubic bezier SVG path using Catmull-Rom fitting.
 */
export function catmullRomToBezier(points: [number, number][]): string {
  if (points.length < 2) return '';
  if (points.length === 2) {
    return `M${points[0][0]},${points[0][1]} L${points[1][0]},${points[1][1]}`;
  }

  let d = `M${points[0][0]},${points[0][1]}`;

  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];

    const cp1x = p1[0] + (p2[0] - p0[0]) / 6;
    const cp1y = p1[1] + (p2[1] - p0[1]) / 6;
    const cp2x = p2[0] - (p3[0] - p1[0]) / 6;
    const cp2y = p2[1] - (p3[1] - p1[1]) / 6;

    d += ` C${cp1x},${cp1y} ${cp2x},${cp2y} ${p2[0]},${p2[1]}`;
  }

  return d;
}

/**
 * Convert a set of points to a linear SVG path (M...L...L...).
 * Produces jagged, hand-ruled lines with angular kinks instead of smooth curves.
 */
export function pointsToLinear(points: [number, number][]): string {
  if (points.length < 2) return '';
  let d = `M${points[0][0]},${points[0][1]}`;
  for (let i = 1; i < points.length; i++) {
    d += ` L${points[i][0]},${points[i][1]}`;
  }
  return d;
}

/**
 * Generate wobble points for a line (intermediate representation before path serialization).
 * Useful for boil frames: generate points once, then perturb per frame.
 */
export function wobbleLinePoints(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  options: WobbleOptions = {},
): [number, number][] {
  const roughness = toFinite(options.roughness, 1);
  const segments = toPositiveInt(options.segments, 8, 2);
  const seed = Math.floor(toFinite(options.seed, 42));
  const rng = mulberry32(seed);

  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  if (len === 0) return [[x1, y1], [x2, y2]];

  const perpX = -dy / len;
  const perpY = dx / len;

  const maxDisplace = roughness * len * 0.015;
  const overshoot = roughness * len * 0.003;

  const sx = x1 - (dx / len) * overshoot * (0.5 + rng() * 0.5);
  const sy = y1 - (dy / len) * overshoot * (0.5 + rng() * 0.5);
  const ex = x2 + (dx / len) * overshoot * (0.5 + rng() * 0.5);
  const ey = y2 + (dy / len) * overshoot * (0.5 + rng() * 0.5);

  const points: [number, number][] = [[sx, sy]];

  for (let i = 1; i < segments; i++) {
    const t = i / segments;
    const mx = x1 + dx * t;
    const my = y1 + dy * t;
    const offset = (rng() - 0.5) * 2 * maxDisplace;
    points.push([mx + perpX * offset, my + perpY * offset]);
  }

  points.push([ex, ey]);
  return points;
}

/**
 * Add small perpendicular perturbations to points for boil frames.
 * Endpoints (first/last) are not perturbed to keep line anchors stable.
 */
export function perturbPoints(
  points: [number, number][],
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  amount: number,
  seed: number,
): [number, number][] {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  if (len === 0) return points.map((p) => [p[0], p[1]]);
  if (points.length <= 2 || amount === 0) return points.map((p) => [p[0], p[1]]);

  const perpX = -dy / len;
  const perpY = dx / len;
  const rng = mulberry32(seed);
  const den = points.length - 1;

  return points.map((point, index) => {
    if (index === 0 || index === points.length - 1) return [point[0], point[1]];
    const t = index / den;
    const taper = Math.pow(Math.sin(Math.PI * t), 0.9);
    const offset = (rng() - 0.5) * 2 * amount * taper;
    return [point[0] + perpX * offset, point[1] + perpY * offset];
  });
}

/**
 * Add perpendicular perturbations to a closed polygon's points for boil frames.
 * Unlike `perturbPoints` (which uses a global line direction), this computes
 * the local tangent at each vertex using its neighbours with modular wrapping,
 * then displaces perpendicular to that tangent.
 *
 * Every point is perturbed (no anchored endpoints) since the path is closed.
 */
export function perturbPointsClosed(
  points: [number, number][],
  amount: number,
  seed: number,
): [number, number][] {
  const n = points.length;
  if (n < 3 || amount === 0) return points.map((p) => [p[0], p[1]]);

  const rng = mulberry32(seed);

  return points.map((p, i) => {
    const prev = points[(i - 1 + n) % n];
    const next = points[(i + 1) % n];
    const dx = next[0] - prev[0];
    const dy = next[1] - prev[1];
    const len = Math.hypot(dx, dy) || 1;
    // Perpendicular to local tangent
    const nx = -dy / len;
    const ny = dx / len;
    const offset = (rng() - 0.5) * 2 * amount;
    return [p[0] + nx * offset, p[1] + ny * offset] as [number, number];
  });
}

/**
 * Generate a wobbly line path between two points.
 */
export function wobbleLine(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  options: WobbleOptions = {},
): string {
  const { jagged = false } = options;
  const points = wobbleLinePoints(x1, y1, x2, y2, options);
  return jagged ? pointsToLinear(points) : catmullRomToBezier(points);
}

/**
 * Generate a wobbly rectangle frame as a closed path.
 */
export function wobbleRect(
  x: number,
  y: number,
  w: number,
  h: number,
  options: WobbleOptions = {},
): string {
  const s = options.seed ?? 42;
  const top = wobbleLine(x, y, x + w, y, { ...options, seed: s });
  const right = wobbleLine(x + w, y, x + w, y + h, { ...options, seed: s + 1 });
  const bottom = wobbleLine(x + w, y + h, x, y + h, { ...options, seed: s + 2 });
  const left = wobbleLine(x, y + h, x, y, { ...options, seed: s + 3 });

  return (
    top +
    ' ' +
    right.replace(/^M[^ ]+/, '') +
    ' ' +
    bottom.replace(/^M[^ ]+/, '') +
    ' ' +
    left.replace(/^M[^ ]+/, '') +
    ' Z'
  );
}

/**
 * Prebake a full boil-frame set for a single line — `frameCount` path strings that a
 * scheduler subscriber cycles through to make the line jitter in place.
 *
 * The base wobble points are generated ONCE (`wobbleLinePoints`), then each frame perturbs
 * that same skeleton by `boilAmount` under a per-frame seed so the anchors stay put while the
 * mid-points shiver — the "generate points once, perturb per frame" convention. Pure of its
 * arguments, so it pairs directly with `useBoilCache([...key], () => boilLineFrames(...))`.
 */
export function boilLineFrames(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  frameCount: number,
  boilAmount: number,
  options: WobbleOptions = {},
): string[] {
  const frames = toPositiveInt(frameCount, 4, 1);
  const amount = toFinite(boilAmount, 0);
  const jagged = options.jagged ?? false;
  const seed = Math.floor(toFinite(options.seed, 42));
  const base = wobbleLinePoints(x1, y1, x2, y2, options);
  const serialize = (pts: [number, number][]) =>
    jagged ? pointsToLinear(pts) : catmullRomToBezier(pts);

  const out: string[] = [];
  for (let f = 0; f < frames; f++) {
    // Frame 0 is the un-perturbed base so a static (frameCount === 1) mark reads as the plain
    // wobble; every later frame shivers off it under a distinct seed.
    const pts = f === 0 ? base : perturbPoints(base, x1, y1, x2, y2, amount, seed + f * 1013);
    out.push(serialize(pts));
  }
  return out;
}

/**
 * Prebake a full boil-frame set for a rectangle frame — `frameCount` closed path strings.
 *
 * Each of the four edges is prebaked independently (offset seeds, as `wobbleRect` does), then
 * the per-frame edges compose into one closed `M…C… … Z` string. Same purity contract as
 * {@link boilLineFrames} — cache it once per structural tuple.
 */
export function boilRectFrames(
  x: number,
  y: number,
  w: number,
  h: number,
  frameCount: number,
  boilAmount: number,
  options: WobbleOptions = {},
): string[] {
  const frames = toPositiveInt(frameCount, 4, 1);
  const s = Math.floor(toFinite(options.seed, 42));
  const top = boilLineFrames(x, y, x + w, y, frames, boilAmount, { ...options, seed: s });
  const right = boilLineFrames(x + w, y, x + w, y + h, frames, boilAmount, { ...options, seed: s + 1 });
  const bottom = boilLineFrames(x + w, y + h, x, y + h, frames, boilAmount, { ...options, seed: s + 2 });
  const left = boilLineFrames(x, y + h, x, y, frames, boilAmount, { ...options, seed: s + 3 });

  const dropMove = (d: string) => d.replace(/^M[^ ]+/, '');
  const out: string[] = [];
  for (let f = 0; f < frames; f++) {
    out.push(
      top[f] + ' ' + dropMove(right[f]) + ' ' + dropMove(bottom[f]) + ' ' + dropMove(left[f]) + ' Z',
    );
  }
  return out;
}

/**
 * Seeded wobble ellipse as a closed point ring with a hand-circled overshoot.
 *
 * Returns POINTS (not a path string) so the ring boils via `perturbPointsClosed`
 * and serialises via `catmullRomToBezier` — the IR-first convention every other
 * primitive here follows (`wobbleLinePoints`). The sweep runs *past* 2π by a
 * seeded fraction so the ring crosses its own start: hand-circled, not snapped.
 */
export function ellipsePoints(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  options: WobbleOptions = {},
): [number, number][] {
  const seg = toPositiveInt(options.segments, 16, 12);
  const rng = mulberry32(Math.floor(toFinite(options.seed, 42)));
  const amp = toFinite(options.roughness, 1) * Math.min(rx, ry) * 0.06;
  const sweep = Math.PI * 2 + (0.05 + rng() * 0.12); // overshoot → hand-circled
  const points: [number, number][] = [];
  for (let i = 0; i <= seg; i++) {
    const a = (sweep * i) / seg - Math.PI / 2;
    const j = (rng() - 0.5) * 2 * amp;
    points.push([cx + Math.cos(a) * (rx + j), cy + Math.sin(a) * (ry + j)]);
  }
  return points;
}

