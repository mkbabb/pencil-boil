# pencil-boil

TypeScript utility library for hand-drawn SVG animation.
Handles deterministic geometry generation, boil-frame perturbation, and frame scheduling for Vue.

## Quick start

```ts
import {
    mulberry32,
    wobbleLine,
    wobbleRect,
    wobbleLinePoints,
    perturbPoints,
    pointsToLinear,
    wobbleDiamond,
    wobbleStarPolygon,
    generateSunRays,
    useLineBoil,
} from "@mkbabb/pencil-boil";
```

## Module map

| Module           | Exports                                                                                                                                                                              | Purpose                                    |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------ |
| `random.ts`      | `mulberry32`                                                                                                                                                                        | Deterministic PRNG                         |
| `path.ts`        | `wobbleLine`, `wobbleRect`, `wobbleLinePoints`, `perturbPoints`, `perturbPointsClosed`, `catmullRomToBezier`, `pointsToLinear`, `boilLineFrames`, `boilRectFrames`, `ellipsePoints`  | Path generation, serialization, prebake    |
| `celestial.ts`   | `wobbleDiamond`, `wobbleStarPolygon`, `generateSunRays`                                                                                                                            | Decorative polygon helpers                 |
| `easings.ts`     | `Easing`, `easeOutCubic`, `easeInCubic`, `easeInOutCubic`, `linear`, `resolveEasing`                                                                                               | Eased tween curves for sequences           |
| `frames.ts`      | `useBoilCache`, `useBoilFrames`                                                                                                                                                    | LRU memoizer for prebaked boil work (per-value `onEvict` disposal) |
| `vue.ts`         | `useLineBoil`, `useFilterParamBoil`, `useRasterStack`, `createBoilTicker`, `createSequenceSubscription`, `createStrokeDrawIn`, `usePrefersReducedMotion`, `schedulerDebugInfo`      | The beat-parked scheduler + tween/draw-in/raster |
| `raster.ts`      | `serializePoseSvg`, `isSelfContainedSvg`, `rasterizePose`, `rasterizePoseStack`                                                                                                    | Bitmap pose cache: bake filtered poses once, swap forever |
| `boilHoldGate.ts` | `acquireHold`, `releaseHold`, `isBoilHeld`, `heldFrameCount`                                                                                                                       | Freeze the boil in place (hold-to-peek)    |

## Animation model

The boil/wobble pipeline has four steps:

1. Seed deterministic randomness.
2. Build base geometry for lines or polygons.
3. Generate frame variants by perturbing interior points.
4. Advance the active frame index on a fixed cadence.

The line keeps its identity across frames, so motion reads as re-tracing with analog
touch instead of full-shape regeneration.

### Stage 1: base geometry

`wobbleLinePoints(x1, y1, x2, y2, options)` builds a deterministic polyline using:

- `roughness` for displacement magnitude.
- `segments` for interior point count.
- `seed` for reproducible geometry.
- endpoint overshoot for a less mechanical edge.

`wobbleLine` serializes points to SVG path data:

- smooth mode via `Catmull-Rom` fitting.
- jagged mode via direct `M/L` segments.

`wobbleRect` composes four independently seeded sides into one closed path. This gives
edge-level variation while keeping a stable frame.

### Stage 2: boil perturbation

`perturbPoints(points, x1, y1, x2, y2, amount, seed)` creates frame-to-frame motion:

- first and last points stay anchored.
- interior points move perpendicular to segment direction.
- perturbation tapers by position, stronger near center and calmer near anchors.

That taper is the key to believable boil; endpoints remain settled while the interior
breathes.

### Stage 3: frame scheduling

`useLineBoil(frameCount, intervalMs)` is the runtime frame cycler, one beat-aligned
tick shared app-wide, asleep between beats:

- accepts numbers, refs, or getters.
- parks on a `setTimeout` aimed at the next beat boundary, wakes to land the writes
  inside ONE `requestAnimationFrame`, then sleeps, with no continuous rAF poll at rest.
- advances by elapsed `intervalMs` measured on the wall clock (`performance.now()`,
  the same clock the beat timer aims with), independent of display refresh.
- pauses on hidden `document.visibilityState`, resumes on restore.
- honors `prefers-reduced-motion` reactively: a mid-session flip tears an active
  subscriber down and gates new enrolment.

A `sequence` subscriber (a draw-in or tween) supersedes the park with a continuous rAF
chain while it runs; the scheduler falls back to parking on completion. However many
boil marks and sequences are live, there's at most one pending wake: a beat timer or a
rAF, never both. The in-repo `boil-guard` proof gates this contract: no rAF at rest,
exactly one rAF per beat, re-park after every tick, sequence supersede-and-fall-back,
and any withdrawal (unmount, PRM, hidden tab) disarms both wake shapes.

Return shape:

```ts
const { currentFrame, start, stop } = useLineBoil(4, 125);
```

### Stage 4: compositing

In practice, compositing usually happens in three layers:

- **Geometry compositing**: combine primitives (`wobbleLine`, `wobbleRect`, celestial
  helpers) into a scene graph.
- **Frame compositing**: precompute `N` perturbed variants, then select by frame index.
- **Visual compositing**: render one or more SVG strokes/fills per frame in UI code.

This package emits geometry and frame indices. Rendering styles, filter stacks, and
domain constraints stay in the consuming application.

## End-to-end usage

```ts
import { computed } from "vue";
import {
    wobbleLinePoints,
    perturbPoints,
    pointsToLinear,
    useLineBoil,
} from "@mkbabb/pencil-boil";

const x1 = 20;
const y1 = 20;
const x2 = 320;
const y2 = 20;

const base = wobbleLinePoints(x1, y1, x2, y2, {
    roughness: 1.2,
    segments: 8,
    seed: 900,
});

const frameCount = 4;
const frames = Array.from({ length: frameCount }, (_, frame) => {
    const perturbed = perturbPoints(base, x1, y1, x2, y2, 0.8, 1200 + frame);
    return pointsToLinear(perturbed);
});

const { currentFrame } = useLineBoil(frameCount, 125);
const d = computed(() => frames[currentFrame.value]);
```

The manual base → perturb → serialize loop above is what `boilLineFrames` (and
`boilRectFrames`) do in one call; wrap them in `useBoilCache` so the frame set is prebaked
once per structural tuple and reused across rerenders:

```ts
import { boilLineFrames, useBoilCache, useLineBoil } from "@mkbabb/pencil-boil";

const frameCount = 4;
const frames = useBoilCache(["hrule", x1, y1, x2, y2, frameCount], () =>
    boilLineFrames(x1, y1, x2, y2, frameCount, 0.8, { seed: 900, jagged: true }),
);

const { currentFrame } = useLineBoil(frameCount, 125);
const d = computed(() => frames[currentFrame.value]);
```

`createStrokeDrawIn(pathEl, { durationMs, easing })` rides the scheduler's continuous chain
(a transient `sequence` subscriber) to draw a path on by hand (stroke-dashoffset from its full
length to `0`), settling to a solid stroke on completion and painting the end state immediately
under `prefers-reduced-motion`.

## Celestial helpers

- `wobbleDiamond`: seeded 4-vertex wobble polygon.
- `wobbleStarPolygon`: seeded 10-vertex star with per-vertex jitter.
- `generateSunRays`: seeded dual-ring irregular ray polygons (`outerPoly`, `innerPoly`).

These helpers are convenient for decorative boil motifs without adding extra generation
code.

## Performance and fidelity

- Keep `segments` moderate (`4`-`10` is common).
- Precompute frame arrays; avoid rebuilding geometry every tick.
- Reuse seeds across rerenders to preserve visual continuity.
- Increase `roughness` and boil `amount` conservatively to maintain line legibility.
- Pause hidden motion to avoid unnecessary work.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md). The README shape follows the perimeter-level
[canonical README shape](https://github.com/mkbabb/glass-ui/blob/master/docs/precepts/canonical-readme-shape.md).

## License

[Unlicense](./LICENSE) — public domain.
